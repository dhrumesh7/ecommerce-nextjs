exports.id = 462;
exports.ids = [462];
exports.modules = {

/***/ 482:
/***/ ((module) => {

// Exports
module.exports = {
	"productTitle": "ProductDetails_productTitle__lBfUP",
	"productDescription": "ProductDetails_productDescription__GbWrM",
	"productPrice": "ProductDetails_productPrice__Qx9Dv",
	"detailsTitle": "ProductDetails_detailsTitle__F_pfa",
	"descriptionText": "ProductDetails_descriptionText__uih03",
	"descriptionTitle": "ProductDetails_descriptionTitle__qnLIU",
	"detailsButton": "ProductDetails_detailsButton__3yR8V",
	"detailsDiv": "ProductDetails_detailsDiv__6E1rK",
	"addToCartButton": "ProductDetails_addToCartButton__eNrTH",
	"addToWishButton": "ProductDetails_addToWishButton__sGkx8",
	"outOfStockNote": "ProductDetails_outOfStockNote__XvU9Z"
};


/***/ }),

/***/ 2872:
/***/ ((module) => {

// Exports
module.exports = {
	"checkoutButton": "cart_checkoutButton__Tn7F_",
	"subTotal": "cart_subTotal__czZQv",
	"title": "cart_title__HoMRx",
	"emptyNote": "cart_emptyNote__mlHgM",
	"productPrice": "cart_productPrice__bAdNb"
};


/***/ })

};
;