exports.id = 329;
exports.ids = [329];
exports.modules = {

/***/ 1903:
/***/ ((module) => {

// Exports
module.exports = {
	"productListTitle": "global_productListTitle__zi9rg",
	"productListDiv": "global_productListDiv__Kmln9",
	"productBox": "global_productBox__Ddb5u",
	"productName": "global_productName__uqOt_",
	"productPrice": "global_productPrice__LwV53",
	"categoryName": "global_categoryName__GegAp",
	"productImage": "global_productImage__jsG_f"
};


/***/ }),

/***/ 5329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductListGrid)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1903);
/* harmony import */ var _styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9783);
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var aos_dist_aos_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1759);
/* harmony import */ var aos_dist_aos_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(aos_dist_aos_css__WEBPACK_IMPORTED_MODULE_5__);







function ProductListGrid({ title , products  }) {
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        aos__WEBPACK_IMPORTED_MODULE_4___default().init();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                title && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: (_styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6___default().productListTitle),
                    children: title || ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    container: true,
                    spacing: 2,
                    rowSpacing: 5,
                    children: products?.map((product, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            item: true,
                            xs: 6,
                            sm: 4,
                            md: 3,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/products/${product.slug}`,
                                style: {
                                    color: "black",
                                    textDecoration: "none"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: product.image?.[0]?.url ? `${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${product._id}/${product.image?.[0]?.url}` : "/product.webp",
                                        alt: "",
                                        className: (_styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6___default().productImage)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6___default().productName),
                                        children: product.title
                                    }),
                                    (product?.noOfferprice - product?.price) / 100 > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                display: "flex",
                                                justifyContent: "center",
                                                alignItems: "center",
                                                gap: 10
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                className: (_styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6___default().productPrice),
                                                children: [
                                                    "₹ ",
                                                    Number(product?.price).toLocaleString("en"),
                                                    " ",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        style: {
                                                            color: "gray",
                                                            textDecoration: "line-through"
                                                        },
                                                        children: [
                                                            " ",
                                                            "₹ ",
                                                            Number(product?.noOfferprice).toLocaleString("en")
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        style: {
                                                            color: "green",
                                                            fontSize: "15px",
                                                            marginLeft: "5px"
                                                        },
                                                        children: [
                                                            Math.round((product?.noOfferprice - product?.price) / 100),
                                                            "% Off"
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                        className: (_styles_global_module_scss__WEBPACK_IMPORTED_MODULE_6___default().productPrice),
                                        children: [
                                            "Rs. ",
                                            Number(product?.price).toLocaleString("en")
                                        ]
                                    })
                                ]
                            })
                        }, index);
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 1759:
/***/ (() => {



/***/ })

};
;