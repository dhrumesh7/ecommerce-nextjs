"use strict";
exports.id = 354;
exports.ids = [354];
exports.modules = {

/***/ 6487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Cart)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4180);
/* harmony import */ var _mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6781);
/* harmony import */ var _mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5951);
/* harmony import */ var _mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _sideNavbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7924);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2872);
/* harmony import */ var _styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(482);
/* harmony import */ var _styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9509);
/* harmony import */ var _mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _services_user_services__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9390);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3590);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sideNavbar__WEBPACK_IMPORTED_MODULE_8__, _services_user_services__WEBPACK_IMPORTED_MODULE_13__, react_toastify__WEBPACK_IMPORTED_MODULE_14__, axios__WEBPACK_IMPORTED_MODULE_15__]);
([_sideNavbar__WEBPACK_IMPORTED_MODULE_8__, _services_user_services__WEBPACK_IMPORTED_MODULE_13__, react_toastify__WEBPACK_IMPORTED_MODULE_14__, axios__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const Img = (0,_mui_material__WEBPACK_IMPORTED_MODULE_7__.styled)("img")({
    margin: "auto",
    display: "block",
    maxWidth: "100%",
    maxHeight: "100%"
});
function Cart({ cartShow , setCartStatus , setCheckoutOpen  }) {
    const [cartItems, setCartItems] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [subTotal, setSubTotal] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    async function fetchData() {
        try {
            const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_13__/* .getCartListService */ .Hr)();
            const cartItems = response?.data?.data?.cart;
            const stockChecked = cartItems.map((item)=>{
                const itemCopy = {
                    ...item
                };
                const skuStock = item?.product?.stocks?.find((stk)=>stk.sku === item.sku)?.stock;
                itemCopy.inStock = skuStock < item.quantity ? false : true;
                return itemCopy;
            });
            console.log("stock checked", stockChecked);
            setCartItems(stockChecked);
        } catch (error) {
        // toast.error(error.message)
        }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (cartShow) {
            fetchData();
        }
    }, [
        cartShow
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        const priceTotal = cartItems.reduce((prev, next)=>next.inStock ? prev + next.product.price * next.quantity : 0, 0);
        setSubTotal(priceTotal);
    }, [
        cartItems
    ]);
    async function handleUpdateQuantity(itemId, newQuantity, sku) {
        console.log("sku", sku);
        if (!newQuantity) return;
        try {
            const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_13__/* .updateCartService */ .RD)({
                productId: itemId,
                quantity: newQuantity,
                sku
            });
            setCartItems((prevCartItems)=>prevCartItems.map((item)=>item.product._id === itemId ? {
                        ...item,
                        quantity: newQuantity
                    } : item));
        } catch (error) {
            react_toastify__WEBPACK_IMPORTED_MODULE_14__.toast.error(error?.response?.data?.message || error.message);
        }
    }
    async function handleRemoveItem(itemId) {
        const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_13__/* .removeCartService */ .lT)(itemId);
        setCartItems((prevCartItems)=>prevCartItems.filter((item)=>item?.product?._id !== itemId));
    }
    const toggleDrawer = (open)=>(event)=>{
            if (event && event.type === "keydown" && (event.key === "Tab" || event.key === "Shift")) {
                return;
            }
            setCartStatus(open);
        };
    const handleCheckout = ()=>{
        // Call Razorpay payment modal here
        setCheckoutOpen(true);
        setCartStatus(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2___default()), {
            anchor: "right",
            open: cartShow,
            onClose: toggleDrawer(false),
            onOpen: toggleDrawer(true),
            sx: {
                maxWidth: "400px"
            },
            PaperProps: {
                sx: {
                    maxWidth: 450
                }
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_sideNavbar__WEBPACK_IMPORTED_MODULE_8__/* .DrawerHeader */ .OX, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            style: {
                                fontSize: 28,
                                textTransform: "uppercase"
                            },
                            children: "Cart"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sideNavbar__WEBPACK_IMPORTED_MODULE_8__/* .CloseIconStyled */ .Mg, {
                            onClick: ()=>setCartStatus(false)
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                cartItems?.length ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        cartItems.map((pr, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                sx: {
                                    padding: "5px"
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        container: true,
                                        spacing: 1,
                                        p: 1,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                item: true,
                                                xs: 3,
                                                sx: {
                                                    opacity: pr.inStock ? "100%" : "50%"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Img, {
                                                        alt: "complex",
                                                        src: `${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${pr?.product?._id}/${pr?.product?.image?.[0]?.url}`
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                item: true,
                                                xs: 7,
                                                container: true,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                    item: true,
                                                    xs: true,
                                                    container: true,
                                                    direction: "column",
                                                    rowSpacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                            item: true,
                                                            xs: true,
                                                            sx: {
                                                                opacity: pr.inStock ? "100%" : "50%"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                                    sx: {
                                                                        color: "darkgoldenrod",
                                                                        textTransform: "capitalize"
                                                                    },
                                                                    gutterBottom: true,
                                                                    variant: "subtitle1",
                                                                    component: "div",
                                                                    children: pr.product.title
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_16___default().descriptionTitle),
                                                                    style: {
                                                                        marginBottom: 0,
                                                                        lineHeight: "inherit",
                                                                        fontSize: "0.8rem"
                                                                    },
                                                                    children: pr.product.color && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                        children: [
                                                                            "COLOR : ",
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                children: [
                                                                                    " ",
                                                                                    pr.product.stocks.find((stk)=>stk.sku === pr.sku)?.color,
                                                                                    " "
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_16___default().descriptionTitle),
                                                                    style: {
                                                                        marginBottom: 0,
                                                                        lineHeight: "inherit",
                                                                        fontSize: "0.8rem"
                                                                    },
                                                                    children: pr.product.size && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                        children: [
                                                                            "SIZE : ",
                                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                                children: [
                                                                                    " ",
                                                                                    pr.product.size,
                                                                                    " "
                                                                                ]
                                                                            })
                                                                        ]
                                                                    })
                                                                })
                                                            ]
                                                        }),
                                                        !pr.inStock && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                            sx: {
                                                                color: "red",
                                                                fontWeight: "500"
                                                            },
                                                            children: "Out of stock"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                            item: true,
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                style: {
                                                                    justifyContent: "flex-start",
                                                                    alignItem: "center",
                                                                    display: "flex"
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ToggleButtonGroup__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                                        size: "small",
                                                                        "aria-label": "text alignment",
                                                                        disabled: pr.inStock ? false : true,
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                size: "small",
                                                                                value: "add",
                                                                                "aria-label": "left aligned",
                                                                                sx: {
                                                                                    height: "35px",
                                                                                    width: "35px"
                                                                                },
                                                                                onClick: ()=>handleUpdateQuantity(pr.product._id, pr.quantity - 1, pr.sku),
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Remove__WEBPACK_IMPORTED_MODULE_12___default()), {})
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                size: "small",
                                                                                value: "",
                                                                                "aria-label": "centered",
                                                                                disabled: true,
                                                                                sx: {
                                                                                    height: "35px",
                                                                                    width: "35px"
                                                                                },
                                                                                children: pr.quantity
                                                                            }),
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ToggleButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                size: "small",
                                                                                value: "remove",
                                                                                "aria-label": "right aligned",
                                                                                sx: {
                                                                                    height: "35px",
                                                                                    width: "35px"
                                                                                },
                                                                                onClick: ()=>handleUpdateQuantity(pr.product._id, pr.quantity + 1, pr.sku),
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_11___default()), {})
                                                                            })
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_7__.Button, {
                                                                        variant: "contained",
                                                                        sx: {
                                                                            backgroundColor: "#000000",
                                                                            color: "white",
                                                                            padding: "0px 15px",
                                                                            fontSize: "12px",
                                                                            ":hover": {
                                                                                color: "#000000",
                                                                                backgroundColor: "white",
                                                                                border: "1px solid #000000"
                                                                            },
                                                                            display: "inline",
                                                                            marginLeft: "15px"
                                                                        },
                                                                        onClick: ()=>handleRemoveItem(pr?.product?._id),
                                                                        children: "Remove"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                item: true,
                                                xs: 2,
                                                sx: {
                                                    opacity: pr.inStock ? "100%" : "50%"
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: (_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default().productPrice),
                                                    children: [
                                                        "₹ ",
                                                        pr.product.price * pr.quantity
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {})
                                ]
                            }, i);
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default().subTotal),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default().title),
                                    style: {
                                        fontWeight: 500
                                    },
                                    children: "Total Amount"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: (_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default().title),
                                    children: [
                                        "₹ ",
                                        subTotal
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: (_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default().checkoutButton),
                            onClick: handleCheckout,
                            children: "PROCEED TO CHECKOUT"
                        })
                    ]
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: (_styles_cart_module_scss__WEBPACK_IMPORTED_MODULE_17___default().emptyNote),
                    children: "Your cart is empty"
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7924:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mg": () => (/* binding */ CloseIconStyled),
/* harmony export */   "OX": () => (/* binding */ DrawerHeader),
/* harmony export */   "ZP": () => (/* binding */ SideNavBar)
/* harmony export */ });
/* unused harmony export MenuIconStyled */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4180);
/* harmony import */ var _mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(834);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _services_category_services__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2033);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_category_services__WEBPACK_IMPORTED_MODULE_13__]);
_services_category_services__WEBPACK_IMPORTED_MODULE_13__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const CloseIconStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_9__.styled)((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11___default()))({
    //   position: "absolute",
    //   top: 20,
    //   right: 20,
    cursor: "pointer",
    fontSize: 32,
    zIndex: 1000,
    strokeWidth: 1
});



// import { redirect, useRouter } from 'next/navigation';

const MenuIconStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_9__.styled)((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_12___default()))({
    position: "fixed",
    top: 20,
    left: 50,
    fontSize: 32,
    zIndex: 1000,
    strokeWidth: 1
});
const DrawerHeader = (0,_mui_material__WEBPACK_IMPORTED_MODULE_9__.styled)("div")(({ theme  })=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: 20,
        position: "sticky",
        top: 0,
        backgroundColor: "white",
        zIndex: 50
    }));
function SideNavBar(props) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_14__.useRouter)();
    const [category, setCategory] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    async function fetchData() {
        const categoryData = await (0,_services_category_services__WEBPACK_IMPORTED_MODULE_13__/* .getAllCategoryService */ .L)();
        // console.log(categoryData?.data?.data)
        const defaultData = [
            {
                name: "SALE",
                category: [],
                link: "/collections/all"
            },
            {
                name: "SHOP",
                category: categoryData?.data?.data,
                link: "/collections/all"
            },
            {
                name: "CONTACT US",
                category: [],
                link: "/contact-us"
            }
        ];
        setCategory(defaultData);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        fetchData();
    }, []);
    const toggleDrawer = (open)=>(event)=>{
            if (event && event.type === "keydown" && (event.key === "Tab" || event.key === "Shift")) {
                return;
            }
            props.setMenuStatus(open);
        };
    const [isCollapseOpen, setCollapseOpen] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const [isSubCollapseOpen, setSubCollapseOpen] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(0);
    const navBarClick = (link)=>{
        router.push({
            pathname: link
        });
        props.setMenuStatus(false);
    };
    const list = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
            sx: {
                width: 300,
                padding: "10px 20px",
                position: "relative"
            },
            role: "presentation",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: category.map((menu, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_5___default()), {
                                disablePadding: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    onClick: ()=>{
                                        isCollapseOpen !== index + 1 ? setCollapseOpen(index + 1) : setCollapseOpen(0);
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            onClick: ()=>navBarClick(menu.link),
                                            primary: menu.name,
                                            sx: {
                                                textTransform: "capitalize",
                                                letterSpacing: 1.4
                                            }
                                        }),
                                        menu?.category?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: isCollapseOpen === index + 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_10__.ExpandLess, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_10__.ExpandMore, {})
                                        })
                                    ]
                                })
                            }, index),
                            menu?.category?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Collapse, {
                                in: isCollapseOpen === index + 1,
                                timeout: "auto",
                                unmountOnExit: true,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    component: "div",
                                    disablePadding: true,
                                    children: menu?.category?.map((category, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    sx: {
                                                        pl: 2
                                                    },
                                                    onClick: ()=>{
                                                        isSubCollapseOpen !== i + 1 ? setSubCollapseOpen(i + 1) : setSubCollapseOpen(0);
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                            primary: category?.name,
                                                            onClick: ()=>navBarClick(`/collections/${category.slug}`)
                                                        }),
                                                        category?.subCategory?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: isSubCollapseOpen == i + 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_10__.ExpandLess, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_icons_material__WEBPACK_IMPORTED_MODULE_10__.ExpandMore, {})
                                                        })
                                                    ]
                                                }, i),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Collapse, {
                                                    in: isSubCollapseOpen === i + 1,
                                                    timeout: "auto",
                                                    unmountOnExit: true,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                        component: "div",
                                                        disablePadding: true,
                                                        children: category?.subCategory?.map((subCategory, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                sx: {
                                                                    pl: 3
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                                    primary: subCategory.name,
                                                                    onClick: ()=>navBarClick(`/collections/${category.slug}/${subCategory.slug}`)
                                                                })
                                                            }, index))
                                                    })
                                                })
                                            ]
                                        }))
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_4___default()), {})
                        ]
                    }))
            })
        });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_SwipeableDrawer__WEBPACK_IMPORTED_MODULE_2___default()), {
            anchor: "left",
            open: props.menuShow,
            onClose: toggleDrawer(false),
            onOpen: toggleDrawer(true),
            sx: {
                position: "relative"
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(DrawerHeader, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            style: {
                                fontSize: 28,
                                textTransform: "uppercase"
                            },
                            children: "Menu"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseIconStyled, {
                            onClick: ()=>props.setMenuStatus(false)
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_4___default()), {}),
                list()
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2033:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ getAllCategoryService)
/* harmony export */ });
/* unused harmony export getAllProductsService */
/* harmony import */ var _api_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6202);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_services__WEBPACK_IMPORTED_MODULE_0__]);
_api_services__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllCategoryService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/category/all", {
    });
};
const getAllProductsService = (query)=>{
    return get("/products/all", {
        params: {
            page: query
        }
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 546:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$h": () => (/* binding */ getSubCategoryProductsService),
/* harmony export */   "Vf": () => (/* binding */ getAllProductsService),
/* harmony export */   "kW": () => (/* binding */ getSimiliarProductsService),
/* harmony export */   "tA": () => (/* binding */ searchProductsService),
/* harmony export */   "vs": () => (/* binding */ getFilterListService),
/* harmony export */   "xs": () => (/* binding */ getCategoryProductsService)
/* harmony export */ });
/* unused harmony export getHomeProductsService */
/* harmony import */ var _api_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6202);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_services__WEBPACK_IMPORTED_MODULE_0__]);
_api_services__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getAllProductsService = (query)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/products/all", {
        params: query
    });
};
const getCategoryProductsService = (query)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/products/category", {
        params: query
    });
};
const getSubCategoryProductsService = (query)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/products/subcategory", {
        params: query
    });
};
const getFilterListService = (query)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/products/filter-list", {
        params: query
    });
};
const getHomeProductsService = ()=>{
    return get("/products/home");
};
const getSimiliarProductsService = (query)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/products/similar", {
        params: query
    });
};
const searchProductsService = (query)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/products/search", {
        params: query
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;