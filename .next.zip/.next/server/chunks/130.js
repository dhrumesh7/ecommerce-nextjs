"use strict";
exports.id = 130;
exports.ids = [130];
exports.modules = {

/***/ 2615:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SideBar)
/* harmony export */ });
/* unused harmony export logOut */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(834);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3787);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_PermIdentity__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(206);
/* harmony import */ var _mui_icons_material_PermIdentity__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PermIdentity__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3804);
/* harmony import */ var _mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_CreditScoreOutlined__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2908);
/* harmony import */ var _mui_icons_material_CreditScoreOutlined__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CreditScoreOutlined__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_EmojiEventsOutlined__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4124);
/* harmony import */ var _mui_icons_material_EmojiEventsOutlined__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_EmojiEventsOutlined__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5967);
/* harmony import */ var _mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_LockResetOutlined__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3254);
/* harmony import */ var _mui_icons_material_LockResetOutlined__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LockResetOutlined__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_PowerSettingsNewOutlined__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7470);
/* harmony import */ var _mui_icons_material_PowerSettingsNewOutlined__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_PowerSettingsNewOutlined__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9332);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _services_auth_services__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(856);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_17__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_auth_services__WEBPACK_IMPORTED_MODULE_16__]);
_services_auth_services__WEBPACK_IMPORTED_MODULE_16__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


















const logOut = async ()=>{
    const response = await (0,_services_auth_services__WEBPACK_IMPORTED_MODULE_16__/* .logOutService */ .YC)();
    const res = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_17__.signOut)({
        callbackUrl: "/"
    });
    console.log("signout ", res);
// push('/')
};
function SideBar() {
    const { push  } = (0,next_navigation__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const drawer = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        "aria-label": "main mailbox folders",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_List__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                    disablePadding: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                        onClick: ()=>push("/account/profile"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PermIdentity__WEBPACK_IMPORTED_MODULE_8___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default()), {
                                primary: "My Profile",
                                style: {
                                    fontSize: "5px"
                                }
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                    disablePadding: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                        onClick: ()=>push("/account/address"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocationOnOutlined__WEBPACK_IMPORTED_MODULE_9___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default()), {
                                primary: "Delivery Address"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_7___default()), {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                    disablePadding: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                        onClick: ()=>push("/account/orders"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CreditScoreOutlined__WEBPACK_IMPORTED_MODULE_10___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default()), {
                                primary: "My Orders"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                    disablePadding: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                        onClick: ()=>push("/account/wishlist"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorderOutlined__WEBPACK_IMPORTED_MODULE_12___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default()), {
                                primary: "My Wishlist"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_7___default()), {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                    disablePadding: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LockResetOutlined__WEBPACK_IMPORTED_MODULE_13___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default()), {
                                primary: "Change Password"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_3___default()), {
                    disablePadding: true,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_4___default()), {
                        onClick: ()=>logOut(),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_5___default()), {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_PowerSettingsNewOutlined__WEBPACK_IMPORTED_MODULE_14___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_6___default()), {
                                primary: "Log Out"
                            })
                        ]
                    })
                })
            ]
        })
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
            sx: {
                width: "100%",
                bgcolor: "background.paper",
                boxShadow: 5,
                borderRadius: "8px",
                height: "max-content"
            },
            children: drawer
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6202:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QO": () => (/* binding */ deleteReq),
/* harmony export */   "U2": () => (/* binding */ get),
/* harmony export */   "r$": () => (/* binding */ patch),
/* harmony export */   "v_": () => (/* binding */ post)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var react_promise_tracker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(312);
/* harmony import */ var react_promise_tracker__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_promise_tracker__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Account_SideBar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2615);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, _components_Account_SideBar__WEBPACK_IMPORTED_MODULE_2__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, _components_Account_SideBar__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const api = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/backend"
});
api.interceptors.request.use((config)=>{
    const options = {
        ...config
    };
    options.headers["Content-Type"] = "application/json";
    options.withCredentials = true;
    return options;
}, (error)=>{
    return Promise.reject(error);
});
api.interceptors.response.use((response)=>{
    return response;
}, async (error)=>{
    if (error.response && [
        401
    ].indexOf(error.response.status) !== -1) {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        localStorage.clear();
        if (true) {
            throw new CustomError(); //Throw custom error here
        } else {}
    }
    return Promise.reject(error);
});
const get = (url, param)=>(0,react_promise_tracker__WEBPACK_IMPORTED_MODULE_1__.trackPromise)(api.get(url, param));
const post = (url, param)=>(0,react_promise_tracker__WEBPACK_IMPORTED_MODULE_1__.trackPromise)(api.post(url, param));
const patch = (url, param)=>(0,react_promise_tracker__WEBPACK_IMPORTED_MODULE_1__.trackPromise)(api.patch(url, param));
const deleteReq = (url, param)=>(0,react_promise_tracker__WEBPACK_IMPORTED_MODULE_1__.trackPromise)(api.delete(url, param));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 856:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SR": () => (/* binding */ emailSingUp),
/* harmony export */   "YC": () => (/* binding */ logOutService),
/* harmony export */   "ZA": () => (/* binding */ emailLogin)
/* harmony export */ });
/* harmony import */ var _api_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6202);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_services__WEBPACK_IMPORTED_MODULE_0__]);
_api_services__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const emailSingUp = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/auth/signup", body);
};
const emailLogin = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/auth/login", body);
};
const logOutService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/auth/logout", body);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;