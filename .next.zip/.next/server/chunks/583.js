exports.id = 583;
exports.ids = [583];
exports.modules = {

/***/ 6993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ImageSlider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);





function ImageSlider({ data  }) {
    var settings = {
        className: "center",
        centerMode: true,
        infinite: false,
        centerPadding: "60px",
        slidesToShow: 1,
        speed: 500
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                width: "90%",
                margin: "0px auto"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                ...settings,
                children: data?.image?.map((image, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: `${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${data?._id}/${image.url}`,
                            alt: "",
                            style: {
                                width: "90%"
                            }
                        })
                    }, index);
                })
            })
        })
    });
}


/***/ }),

/***/ 9123:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);





function ProductListSlider() {
    var settings = {
        dots: true,
        infinite: false,
        speed: 500,
        slidesToShow: 5,
        slidesToScroll: 5,
        initialSlide: 0,
        //   variableWidth: true,
        responsive: [
            {
                breakpoint: 1300,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 1100,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    initialSlide: 3
                }
            },
            {
                breakpoint: 775,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            }
        ]
    };
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs("div", {
            className: globalStyles.productListDiv,
            children: [
                /*#__PURE__*/ _jsx("h3", {
                    className: globalStyles.productListTitle,
                    children: "Product List"
                }),
                /*#__PURE__*/ _jsxs(Slider, {
                    ...settings,
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: globalStyles.productBox,
                            style: {
                                width: 225
                            },
                            children: [
                                /*#__PURE__*/ _jsx("img", {
                                    src: "/product.webp",
                                    alt: "",
                                    style: {
                                        width: "98%"
                                    }
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productName,
                                    children: "Pentagon Dark Blue Denim Shirt"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: globalStyles.productPrice,
                                    children: "Rs. 1,999"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 4583:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addToCart": () => (/* binding */ addToCart),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_productList_productListGrid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5329);
/* harmony import */ var _components_productList_productListSlider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9123);
/* harmony import */ var _components_sideNavbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7924);
/* harmony import */ var _components_cart__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6487);
/* harmony import */ var _styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(482);
/* harmony import */ var _styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _services_products_services__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(546);
/* harmony import */ var _services_user_services__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9390);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3590);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_Styled__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4426);
/* harmony import */ var _components_productList_imageSlider__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6993);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_sideNavbar__WEBPACK_IMPORTED_MODULE_5__, _components_cart__WEBPACK_IMPORTED_MODULE_6__, _services_products_services__WEBPACK_IMPORTED_MODULE_8__, _services_user_services__WEBPACK_IMPORTED_MODULE_9__, react_toastify__WEBPACK_IMPORTED_MODULE_10__]);
([_components_sideNavbar__WEBPACK_IMPORTED_MODULE_5__, _components_cart__WEBPACK_IMPORTED_MODULE_6__, _services_products_services__WEBPACK_IMPORTED_MODULE_8__, _services_user_services__WEBPACK_IMPORTED_MODULE_9__, react_toastify__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const addToCart = async (productId, sku)=>{
    try {
        if (!sku || !productId) react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.error("Sorry! We can't add this product to cart.");
        const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_9__/* .addToCartService */ .ov)({
            productId,
            sku
        });
        if (response.data.flag) {
            react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.success(response?.data?.message);
        }
    } catch (error) {
        react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.error(error?.response?.data?.message || error.message);
    }
};
const Product = ({ data  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const desktop = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.up("md"));
    const tablet = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.between("sm", "md"));
    const mobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    // const [inStock, setInStock]= useState(false);
    const [product, setProduct] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        name: "Pintek Navy Shirt",
        images: [
            "/product.jpg",
            "/product.jpg",
            "/product.jpg",
            "/product.jpg",
            "/product.jpg"
        ],
        price: 1999,
        description: "EMI Options Are available !"
    });
    const [selectedColor, setSelectedColor] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [selectedSku, setSelectedSku] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [isApiCall, setApiCall] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [similarProducts, setSimilarProducts] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    async function fetchData() {
        try {
            const response = await (0,_services_products_services__WEBPACK_IMPORTED_MODULE_8__/* .getSimiliarProductsService */ .kW)({
                category: data.category,
                subcategory: data.subcategory
            });
            setSimilarProducts(response?.data?.data?.similarProducts);
            setApiCall(true);
        } catch (error) {
            console.log(error);
        }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchData();
    }, []);
    const addToWishList = async ()=>{
        try {
            const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_9__/* .addToWishListService */ .Op)({
                productId: data._id
            });
            if (response.data.flag) {
                react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.success(response?.data?.message);
            }
        } catch (error) {
            react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.error(error?.response?.data?.message || error.message);
        }
    };
    const [activeImage, setActiveImage] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("1");
    const handleChange = (event, newValue)=>{
        setValue(newValue);
    };
    // const RenderTab = (value) => {
    //   switch (value) {
    //     case '1':
    //       return <>dsfdsfsf</>;
    //     default:
    //       break;
    //   }
    // };
    let inStock = false;
    data?.stocks?.every((stk)=>{
        if (stk.stock) {
            console.log("yes i;m in");
            inStock = true;
            return false;
        } else {
            return true;
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setActiveImage(`${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${data?._id}/${data?.image?.[0]?.url}`);
    }, [
        data
    ]);
    const handleColorChange = (color)=>{
        const sku = data?.stocks?.find((stk)=>stk.color.toLowerCase() === color.toLowerCase())?.sku;
        setSelectedSku(sku);
        setSelectedColor(color);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isApiCall && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Styled__WEBPACK_IMPORTED_MODULE_12__/* .ContainerStyled */ .N, {
            style: {
                marginTop: "25px",
                marginBottom: "25px"
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    container: true,
                    spacing: 4,
                    children: [
                        data && desktop && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            container: true,
                            item: true,
                            xs: 0,
                            md: 6,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                    item: true,
                                    xs: 0,
                                    md: 2,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ImageList, {
                                        variant: "masonry",
                                        cols: 1,
                                        gap: 5,
                                        sx: {
                                            margin: 0
                                        },
                                        children: data?.image?.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ImageListItem, {
                                                sx: {
                                                    width: "80%",
                                                    cursor: "pointer"
                                                },
                                                onClick: ()=>setActiveImage(`${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${data._id}/${item.url}`),
                                                style: `${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${data._id}/${item.url}` == activeImage ? {
                                                    border: "1px solid",
                                                    padding: 2
                                                } : {},
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: `${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${data?._id}/${item?.url}`,
                                                    alt: product?.title,
                                                    loading: "lazy"
                                                })
                                            }, item))
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                    item: true,
                                    xs: 12,
                                    md: 10,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: `${activeImage}`,
                                        alt: "activeImage",
                                        style: {
                                            width: "100%",
                                            margin: "0 auto"
                                        },
                                        loading: "lazy"
                                    })
                                })
                            ]
                        }),
                        !desktop && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            item: true,
                            xs: 12,
                            children: [
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_productList_imageSlider__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    data: data
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            item: true,
                            xs: 12,
                            md: 6,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().productTitle),
                                    children: data?.title
                                }),
                                (data?.noOfferprice - data?.price) / 100 > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().productPrice),
                                            children: [
                                                "Rs. ",
                                                Number(data?.price).toLocaleString("en"),
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    style: {
                                                        color: "green",
                                                        fontSize: "0.8em"
                                                    },
                                                    children: [
                                                        Math.round((data?.noOfferprice - data?.price) / 100),
                                                        "% Off"
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            style: {
                                                color: "gray"
                                            },
                                            children: [
                                                "MRP",
                                                " ",
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    style: {
                                                        textDecoration: "line-through"
                                                    },
                                                    children: [
                                                        "Rs. ",
                                                        Number(data?.noOfferprice).toLocaleString("en")
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().productPrice),
                                    children: [
                                        "Rs. ",
                                        Number(data?.price).toLocaleString("en")
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().productDescription),
                                    children: data?.description?.other
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().detailsDiv),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().detailsTitle),
                                            children: "COLOR"
                                        }),
                                        data?.color.map((clr, index)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                disabled: !data.stocks.find((stock)=>stock?.color.toLowerCase() === clr.toLowerCase()),
                                                className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().detailsButton),
                                                onClick: ()=>handleColorChange(clr),
                                                style: {
                                                    border: selectedColor === clr ? "1px solid black" : "1px solid #e0f1fd"
                                                },
                                                children: [
                                                    console.log("sku ", data.stocks),
                                                    clr
                                                ]
                                            }, index);
                                        })
                                    ]
                                }),
                                console.log("instaock", inStock),
                                !inStock && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().outOfStockNote),
                                    children: `Sorry, we're temporarily out of stock.`
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().addToCartButton),
                                    style: {
                                        opacity: inStock ? "100%" : "50%"
                                    },
                                    disabled: !inStock,
                                    onClick: ()=>{
                                        if (data?.color?.length > 1 && !selectedColor) {
                                            return react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.info("Please choose color.");
                                        }
                                        addToCart(data._id, selectedSku);
                                    },
                                    children: "ADD TO CART"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().addToWishButton),
                                    onClick: ()=>addToWishList(),
                                    children: "SAVE TO WISHLIST"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionText),
                                            style: {
                                                marginBottom: 25
                                            },
                                            children: data?.description?.descriptionText
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionTitle),
                                                    children: "PRODUCT DESCRIPTION"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionUl),
                                                    children: data?.description?.features.map((feature, index)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionText),
                                                            children: feature
                                                        }, index);
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionTitle),
                                                    children: [
                                                        "Fabric : ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: data?.description?.fabric
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionTitle),
                                                    children: [
                                                        "Occasion : ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: data?.description?.occasion?.join(", ")
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: (_styles_ProductDetails_module_scss__WEBPACK_IMPORTED_MODULE_15___default().descriptionTitle),
                                                    children: [
                                                        "Care Instructions : ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: data?.description?.care
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_11__.Box, {
                    sx: {
                        width: "100%",
                        maxWidth: "100%"
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tabs, {
                            value: value,
                            onChange: handleChange,
                            textColor: "secondary",
                            indicatorColor: "secondary",
                            variant: "scrollable",
                            scrollButtons: "auto",
                            allowScrollButtonsMobile: true,
                            "aria-label": "secondary tabs example",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tab, {
                                    value: "1",
                                    wrapped: true,
                                    label: "Manufacturer Details"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tab, {
                                    value: "2",
                                    wrapped: true,
                                    label: "Returns & Exchange Policy"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Tab, {
                                    value: "3",
                                    wrapped: true,
                                    label: "Place Return / Exchange Request"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_11__.Box, {
                            sx: {
                                p: 3,
                                boxShadow: "0px 5px 5px #ccc",
                                borderRadius: "0 0 10px 10px",
                                fontWeight: 300,
                                letterSpacing: 1,
                                fontSize: "13px"
                            },
                            children: [
                                value === "1" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            style: {
                                                fontWeight: 600
                                            },
                                            children: "Manufactured & Marketed By:"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " Arya Silk Mills",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "A-UG-527 Avadh Rituraj Textile Hub, Saroli, Surat - 395003",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            style: {
                                                fontWeight: 600
                                            },
                                            children: [
                                                "Country of Origin:",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                                            ]
                                        }),
                                        "India"
                                    ]
                                }),
                                value === "2" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    style: {
                                        lineHeight: 2
                                    },
                                    children: [
                                        "We offer 7 days hassle-free returns and exchange. Return Policies may vary based on products and promotions. ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        " 1) Refunds for Prepaid orders would directly be initiated to source account and COD order will be refunded in the form of COUPON CODE ONLY",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "2) Defective Products, Wrong Products or Damaged Products issue should be raised within 24 hrs of delivery",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        "3) All Orders wherein FREE Products included are not eligible"
                                    ]
                                }),
                                value === "3" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    id: "tab3",
                                    class: "tabcontent active",
                                    children: [
                                        "To place any Returns / Exchange Request,",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_14___default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                children: "click here."
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_productList_productListGrid__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    title: "SIMILR PRODUCTS",
                    products: similarProducts
                })
            ]
        })
    });
};
async function getServerSideProps({ params  }) {
    let data;
    try {
        const res = await fetch(`${"http://3.111.148.12:4020"}/products/product/${params.id}`);
        data = await res.json();
    } catch (error) {
        console.log("eer", error);
    }
    if (!data?.data) return {
        redirect: {
            permanent: false,
            destination: "/404"
        }
    };
    return {
        props: {
            data: data?.data
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Product);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ })

};
;