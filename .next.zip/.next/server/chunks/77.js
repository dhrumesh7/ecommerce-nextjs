"use strict";
exports.id = 77;
exports.ids = [77];
exports.modules = {

/***/ 4426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ ContainerStyled)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ContainerStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)("div")(({ theme  })=>({
        maxWidth: "1200px",
        margin: "0px auto",
        [theme.breakpoints.down("lg")]: {
            margin: "0px 25px"
        }
    }));


/***/ }),

/***/ 9390:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ao": () => (/* binding */ getOrderService),
/* harmony export */   "Hr": () => (/* binding */ getCartListService),
/* harmony export */   "Op": () => (/* binding */ addToWishListService),
/* harmony export */   "RD": () => (/* binding */ updateCartService),
/* harmony export */   "hj": () => (/* binding */ getOrderListService),
/* harmony export */   "kg": () => (/* binding */ removeFromWishListService),
/* harmony export */   "lT": () => (/* binding */ removeCartService),
/* harmony export */   "mU": () => (/* binding */ updateUserProfileService),
/* harmony export */   "ov": () => (/* binding */ addToCartService),
/* harmony export */   "rc": () => (/* binding */ getWishListService),
/* harmony export */   "s9": () => (/* binding */ getUserProfileService),
/* harmony export */   "t8": () => (/* binding */ addAddressService)
/* harmony export */ });
/* harmony import */ var _api_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6202);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_services__WEBPACK_IMPORTED_MODULE_0__]);
_api_services__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getUserProfileService = ()=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/user");
};
const updateUserProfileService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .patch */ .r$)("/user", body);
};
const addAddressService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/user/address", body);
};
const addToWishListService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/user/wishlist", body);
};
const removeFromWishListService = (productId)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .deleteReq */ .QO)(`/user/wishlist/${productId}`);
};
const getWishListService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/user/wishlist", body);
};
const addToCartService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/user/cart", body);
};
const updateCartService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .patch */ .r$)("/user/cart", body);
};
const removeCartService = (productId)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .deleteReq */ .QO)(`/user/cart/${productId}`);
};
const getCartListService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/user/cart");
};
const getOrderListService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)("/user/orders");
};
const getOrderService = (orderId)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .get */ .U2)(`/user/order/${orderId}`);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;