(() => {
var exports = {};
exports.id = 771;
exports.ids = [771];
exports.modules = {

/***/ 4373:
/***/ ((module) => {

// Exports
module.exports = {
	"profileSideBarMain": "Account_profileSideBarMain__DnDr5",
	"inputMain": "Account_inputMain__yDUIg",
	"inputDiv": "Account_inputDiv__LuvXj",
	"inputMainRadio": "Account_inputMainRadio__wIiUH",
	"inputDivRadio": "Account_inputDivRadio__vHNhJ",
	"inputBox": "Account_inputBox__ZF5Tv",
	"saveButton": "Account_saveButton__f9wiw",
	"outerBoxDetails": "Account_outerBoxDetails__jKWbS",
	"addressBoxContent": "Account_addressBoxContent__Smhk_",
	"productImage": "Account_productImage__3ff0k"
};


/***/ }),

/***/ 5052:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";

// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: external "cookies-next"
const external_cookies_next_namespaceObject = require("cookies-next");
;// CONCATENATED MODULE: ./components/WithAuth/WithAuth.js




const withAuth = (WrappedComponent)=>{
    const WithAuth = (props)=>{
        const router = useRouter();
        useEffect(()=>{
            const token = getCookie();
            console.log("token", token);
            if (!token) {
                router.push("/login");
            }
        }, []);
        return /*#__PURE__*/ _jsx(WrappedComponent, {
            ...props
        });
    };
    WithAuth.displayName = `WithAuth(${WrappedComponent.displayName || WrappedComponent.name || "Component"})`;
    return WithAuth;
};
/* harmony default export */ const WithAuth = ((/* unused pure expression or super */ null && (withAuth)));


/***/ }),

/***/ 5149:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6902);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6380);
/* harmony import */ var _mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5641);
/* harmony import */ var _components_Account_SideBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2615);
/* harmony import */ var _styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4373);
/* harmony import */ var _styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_WithAuth_WithAuth__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5052);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _services_user_services__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9390);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3590);
/* harmony import */ var _components_Styled__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4426);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _components_Account_SideBar__WEBPACK_IMPORTED_MODULE_5__, _services_user_services__WEBPACK_IMPORTED_MODULE_9__, react_toastify__WEBPACK_IMPORTED_MODULE_10__]);
([react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _components_Account_SideBar__WEBPACK_IMPORTED_MODULE_5__, _services_user_services__WEBPACK_IMPORTED_MODULE_9__, react_toastify__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














async function getServerSideProps({ req  }) {
    const parsedCookies = cookie__WEBPACK_IMPORTED_MODULE_8__.parse(req?.headers?.cookie || "");
    const token = parsedCookies?.token;
    if (!token) {
        return {
            redirect: {
                destination: "/login",
                permanent: false
            }
        };
    }
    return {
        props: {}
    };
}
const Profile = ()=>{
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)();
    const [isEdit, setIsEdit] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const { register , handleSubmit , control , reset  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
        defaultValues: {
            gender: "male"
        }
    });
    async function fetchData() {
        try {
            const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_9__/* .getUserProfileService */ .s9)();
            const userData = response?.data?.data;
            setUser(userData);
            reset({
                firstName: userData.firstName,
                lastName: userData.lastName,
                email: userData.email,
                contactNumber: userData.contactNumber
            });
            console.log(response.data);
        } catch (error) {
            console.log("err", error);
        }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        fetchData();
        console.log("user", user);
    }, []);
    const saveFormData = async (data)=>{
        console.log(data);
        try {
            const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_9__/* .updateUserProfileService */ .mU)(data);
            setUser(response?.data);
        } catch (error) {
            react_toastify__WEBPACK_IMPORTED_MODULE_10__.toast.error(error?.response?.data?.message || error.message);
        }
    // const updated = awa
    };
    const editClick = ()=>{
        setIsEdit(!isEdit);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Styled__WEBPACK_IMPORTED_MODULE_11__/* .ContainerStyled */ .N, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default().profileSideBarMain),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                spacing: 2,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        item: true,
                        xs: 12,
                        md: 4,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Account_SideBar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        item: true,
                        xs: 12,
                        md: 8,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                            component: "div",
                            boxShadow: 5,
                            className: (_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default().outerBoxDetails),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                    onSubmit: handleSubmit(saveFormData),
                                    style: {
                                        width: "100%"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        container: true,
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "firstName",
                                                        children: "First Name"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        autoComplete: "email",
                                                        className: (_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default().inputBox),
                                                        ...register("firstName", {
                                                            required: true
                                                        }),
                                                        disabled: !isEdit
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "lastName",
                                                        children: "Last Name"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        autoComplete: "email",
                                                        className: (_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default().inputBox),
                                                        ...register("lastName", {
                                                            required: true
                                                        }),
                                                        disabled: !isEdit
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "email",
                                                        children: "Email"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "email",
                                                        autoComplete: "email",
                                                        className: (_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default().inputBox),
                                                        ...register("email", {
                                                            required: true
                                                        }),
                                                        disabled: !isEdit
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                sm: 6,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "contactNumber",
                                                        children: "Contact Number"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "number",
                                                        autoComplete: "email",
                                                        className: (_styles_Account_module_scss__WEBPACK_IMPORTED_MODULE_12___default().inputBox),
                                                        ...register("contactNumber", {
                                                            required: true
                                                        }),
                                                        disabled: !isEdit
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControl, {
                                                    component: "fieldset",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormLabel, {
                                                            component: "legend",
                                                            style: {
                                                                color: "black"
                                                            },
                                                            children: "Gender"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.Controller, {
                                                            rules: {
                                                                required: true
                                                            },
                                                            control: control,
                                                            name: "gender",
                                                            render: ({ field  })=>{
                                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.RadioGroup, {
                                                                    ...field,
                                                                    row: true,
                                                                    style: {
                                                                        columnGap: "50px",
                                                                        marginTop: "10px"
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                                                                            value: "male",
                                                                            control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                                                                                disabled: !isEdit
                                                                            }),
                                                                            label: "Male"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                                                                            value: "female",
                                                                            control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                                                                                disabled: !isEdit
                                                                            }),
                                                                            label: "Female"
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, {
                                                                            value: "other",
                                                                            control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                                                                                disabled: !isEdit
                                                                            }),
                                                                            label: "Other"
                                                                        })
                                                                    ]
                                                                });
                                                            }
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                                item: true,
                                                xs: 12,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                    type: "submit",
                                                    variant: "contained",
                                                    sx: {
                                                        backgroundColor: "darkgoldenrod",
                                                        color: "white",
                                                        width: "200px",
                                                        padding: "10px",
                                                        ":hover": {
                                                            color: "darkgoldenrod",
                                                            backgroundColor: "white",
                                                            border: "1px solid darkgoldenrod"
                                                        },
                                                        display: "block",
                                                        margin: "0 auto"
                                                    },
                                                    children: "Save"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    style: {
                                        position: "absolute",
                                        right: "10px",
                                        top: "10px"
                                    },
                                    onClick: ()=>editClick(),
                                    children: isEdit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_HighlightOff__WEBPACK_IMPORTED_MODULE_3___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_2___default()), {})
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Profile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2908:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CreditScoreOutlined");

/***/ }),

/***/ 6902:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 4124:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/EmojiEventsOutlined");

/***/ }),

/***/ 5967:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/FavoriteBorderOutlined");

/***/ }),

/***/ 6380:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HighlightOff");

/***/ }),

/***/ 3804:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocationOnOutlined");

/***/ }),

/***/ 3254:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LockResetOutlined");

/***/ }),

/***/ 206:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PermIdentity");

/***/ }),

/***/ 7470:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PowerSettingsNewOutlined");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 4192:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/List");

/***/ }),

/***/ 834:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItem");

/***/ }),

/***/ 1011:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemButton");

/***/ }),

/***/ 3787:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 4802:
/***/ ((module) => {

"use strict";
module.exports = require("cookie");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 312:
/***/ ((module) => {

"use strict";
module.exports = require("react-promise-tracker");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [332,130,77], () => (__webpack_exec__(5149)));
module.exports = __webpack_exports__;

})();