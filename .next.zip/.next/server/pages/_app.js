(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 439:
/***/ ((module) => {

// Exports
module.exports = {
	"mainHeader": "Layout_mainHeader__zEaKL",
	"mainHeaderContainer": "Layout_mainHeaderContainer__vQEI_",
	"iconDev": "Layout_iconDev__AdNV8",
	"iconList": "Layout_iconList__tp3VG"
};


/***/ }),

/***/ 1431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/category.bb6f6380.jpg","height":360,"width":360,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAAAwEBAAAAAAAAAAAAAAAAAAAAA//aAAwDAQACEAMQAAAAiCb/xAAcEAEAAgEFAAAAAAAAAAAAAAADAQIEAAUGEzH/2gAIAQEAAT8AxeVYLbkLEZHKqvZdvaHEa//EABcRAQADAAAAAAAAAAAAAAAAAAEAAhH/2gAIAQIBAT8ARFyyT//EABcRAQEBAQAAAAAAAAAAAAAAAAERAAL/2gAIAQMBAT8Aoy8jv//Z","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Checkout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8611);
/* harmony import */ var _mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_ButtonBase__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2494);
/* harmony import */ var _mui_material_ButtonBase__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ButtonBase__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _public_category_jpg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1431);
/* harmony import */ var _services_user_services__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9390);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3590);
/* harmony import */ var _services_payment_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1232);
/* harmony import */ var _AddressForm__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2992);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9332);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_user_services__WEBPACK_IMPORTED_MODULE_11__, react_toastify__WEBPACK_IMPORTED_MODULE_12__, _services_payment_service__WEBPACK_IMPORTED_MODULE_13__, _AddressForm__WEBPACK_IMPORTED_MODULE_14__]);
([_services_user_services__WEBPACK_IMPORTED_MODULE_11__, react_toastify__WEBPACK_IMPORTED_MODULE_12__, _services_payment_service__WEBPACK_IMPORTED_MODULE_13__, _AddressForm__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const Img = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.styled)("img")({
    margin: "auto",
    display: "block",
    maxWidth: "100%",
    maxHeight: "100%"
});
const CloseIconStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.styled)((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_16___default()))({
    position: "absolute",
    top: 10,
    right: 10,
    cursor: "pointer",
    fontSize: 32,
    zIndex: 1000,
    strokeWidth: 1
});
function Checkout({ setCheckoutOpen  }) {
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [deliveryAddress, setDeliveryAddress] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const [selectedAddress, setSelectedAddress] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [cartItems, setCartItems] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const [priceTotal, setPriceTotal] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const [currentStep, setCurrentStep] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(1);
    // const [addNew, setAddNew] = useState(false);
    //   const [default, setDeliveryAddress] = useState([])
    async function fetchData() {
        try {
            const response = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_11__/* .getUserProfileService */ .s9)();
            const addresses = response?.data?.data?.deliveryAddress;
            setUser(response?.data?.data);
            setDeliveryAddress(addresses);
            setSelectedAddress(addresses?.find((address)=>address.isDefault)?._id);
            const cartrResponse = await (0,_services_user_services__WEBPACK_IMPORTED_MODULE_11__/* .getCartListService */ .Hr)();
            const cartItems = cartrResponse?.data?.data?.cart;
            const stockChecked = cartItems.filter((item)=>{
                const skuStock = item?.product?.stocks?.find((stk)=>stk.sku === item.sku)?.stock;
                return skuStock > item.quantity;
            });
            const priceTotal = stockChecked.reduce((prev, next)=>prev + next.product.price * next.quantity, 0);
            setCartItems(stockChecked);
            setPriceTotal(priceTotal);
        } catch (error) {
            console.log("er", error);
        }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        fetchData();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        console.log("delivry address", deliveryAddress);
    }, [
        deliveryAddress
    ]);
    const handleAddressChange = (event)=>{
        console.log(event.target.value);
        setSelectedAddress(event.target.value);
    };
    console.log("render");
    function loadScript(src) {
        return new Promise((resolve)=>{
            const script = document.createElement("script");
            script.src = src;
            script.onload = ()=>{
                resolve(true);
            };
            script.onerror = ()=>{
                resolve(false);
            };
            document.body.appendChild(script);
        });
    }
    async function displayRazorpay() {
        const res = await loadScript("https://checkout.razorpay.com/v1/checkout.js");
        if (!res) {
            react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.error("Razorpay SDK failed to load. Are you online?");
            return;
        }
        const address = deliveryAddress.find((address)=>address._id === selectedAddress);
        const checkoutData = {
            cartItems,
            priceTotal,
            address
        };
        try {
            const result = await (0,_services_payment_service__WEBPACK_IMPORTED_MODULE_13__/* .createOrderService */ .A1)(checkoutData);
            const { amount , id: order_id , currency  } = result.data;
            const options = {
                key: "rzp_test_wSKSrOLwNIS37y",
                amount: amount.toString(),
                currency: currency,
                name: "Arya Silk Mills",
                description: "Test Transaction",
                image: {
                    logo: _public_category_jpg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z
                },
                order_id: order_id,
                handler: async function(response) {
                    console.log(response);
                    const data = {
                        orderCreationId: order_id,
                        razorpayPaymentId: response.razorpay_payment_id,
                        razorpayOrderId: response.razorpay_order_id,
                        razorpaySignature: response.razorpay_signature
                    };
                    try {
                        const result = await (0,_services_payment_service__WEBPACK_IMPORTED_MODULE_13__/* .paymentSuccessService */ .J1)(data);
                        react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.success("Your order has been successfully placed!");
                        router.push(`/account/orders/${result?.data?.order?._id}`);
                    } catch (error) {
                        (0,react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast)(result.data.msg);
                    }
                },
                prefill: {
                    name: `${user.firstName} ${user.lastName}"`,
                    email: user.email,
                    contact: selectedAddress.contactNumber
                },
                notes: {
                    address: "Gopinath Infotech, Surat"
                },
                theme: {
                    color: "#61dafb"
                }
            };
            const paymentObject = new window.Razorpay(options);
            paymentObject.on("payment.failed", async function(response) {
                console.log("Payment failed", response.error);
                // alert('Payment failed: ' + response.error.description);
                try {
                    const result = await (0,_services_payment_service__WEBPACK_IMPORTED_MODULE_13__/* .paymentFailureService */ .qg)(response.error);
                    console.log("payment fail result", result);
                } catch (error) {
                    console.log("payment fail error", error);
                }
            });
            paymentObject.open();
        } catch (error) {
            return react_toastify__WEBPACK_IMPORTED_MODULE_12__.toast.error(error?.response?.data?.message || error.message);
        }
    }
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    const handleOpen = ()=>{
        setOpen(true);
    };
    const handleClose = ()=>{
        setOpen(false);
        setCheckoutOpen(false);
    };
    const handleNewAddressChange = (event)=>{
        setNewAddress((prevAddress)=>({
                ...prevAddress,
                [event.target.name]: event.target.value
            }));
    };
    const handleAddNewAddress = (event)=>{
        event.preventDefault();
        setCurrentStep(0);
    // setAddNew(true);
    // setDefaultAddress(newAddress);
    // handleClose();
    };
    const handleCheckout = ()=>{
    // Call Razorpay payment modal here
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        console.log("selecte ", selectedAddress);
    }, [
        selectedAddress
    ]);
    const onContinue = async ()=>{
        setCheckoutOpen(false);
        await displayRazorpay();
    };
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useTheme)();
    const RenderComponent = ()=>{
        switch(currentStep){
            case 1:
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                            variant: "h6",
                            id: "address-modal-title",
                            sx: {
                                marginBottom: "10px"
                            },
                            children: "Select Shipping Address"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                maxHeight: 200,
                                overflow: "auto"
                            },
                            children: [
                                deliveryAddress?.map((address, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        sx: {
                                            display: "flex",
                                            flexDirection: "row",
                                            alignItems: "center",
                                            border: "1px solid darkgoldenrod",
                                            borderRadius: 4,
                                            padding: 2,
                                            width: "100%",
                                            marginBottom: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Radio, {
                                                sx: {
                                                    color: "black",
                                                    "&.Mui-checked": {
                                                        color: "darkgoldenrod"
                                                    }
                                                },
                                                onChange: handleAddressChange,
                                                value: address._id,
                                                checked: selectedAddress === address._id
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                sx: {
                                                    display: "flex",
                                                    flexDirection: "column",
                                                    fontSize: "20px"
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        sx: {
                                                            fontWeight: "500",
                                                            fontSize: "12px"
                                                        },
                                                        children: address.firstName
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        sx: {
                                                            fontWeight: "400",
                                                            fontSize: "12px"
                                                        },
                                                        children: [
                                                            address.address1,
                                                            " ",
                                                            address.address2
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        sx: {
                                                            fontWeight: "400",
                                                            fontSize: "12px"
                                                        },
                                                        children: [
                                                            address.city,
                                                            ", ",
                                                            address.state,
                                                            " ",
                                                            address.pincode
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, index);
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    my: 2,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                        variant: "contained",
                                        sx: {
                                            backgroundColor: "white",
                                            color: "darkgoldenrod",
                                            ":hover": {
                                                color: "white",
                                                backgroundColor: "black"
                                            },
                                            border: "1px solid darkgoldenrod"
                                        },
                                        onClick: handleAddNewAddress,
                                        children: "Add New Address"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                            my: 2,
                            sx: {
                                alignItems: "center"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                variant: "contained",
                                sx: {
                                    background: "darkgoldenrod",
                                    margin: "0px auto",
                                    display: "block",
                                    ":hover": {
                                        color: "white",
                                        backgroundColor: "black"
                                    }
                                },
                                disabled: !selectedAddress,
                                onClick: ()=>setCurrentStep(2),
                                children: "Continue"
                            })
                        })
                    ]
                });
            case 0:
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AddressForm__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        setIsEdit: (data)=>setCurrentStep(1),
                        deliveryAddress: deliveryAddress,
                        setDeliveryAddress: (data)=>setDeliveryAddress(data)
                    })
                });
            case 2:
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                    item: true,
                    xs: 12,
                    md: 6,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                            variant: "h6",
                            sx: {
                                marginBottom: "10px"
                            },
                            children: [
                                " ",
                                "Select Payment Method",
                                " "
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                padding: "20px 0",
                                display: "flex",
                                justifyContent: "space-evenly"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                    variant: "contained",
                                    sx: {
                                        backgroundColor: "#ffffff",
                                        color: "#000000",
                                        width: "48%",
                                        padding: "10px",
                                        border: "1px solid #000000",
                                        ":hover": {
                                            color: "#ffffff",
                                            backgroundColor: "#000000"
                                        },
                                        display: "block",
                                        margin: "0px auto"
                                    },
                                    children: "Cash On Delivery"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                    variant: "contained",
                                    onClick: ()=>onContinue(),
                                    sx: {
                                        backgroundColor: "#000000",
                                        color: "white",
                                        width: "48%",
                                        padding: "10px",
                                        ":hover": {
                                            color: "#000000",
                                            backgroundColor: "white",
                                            border: "1px solid #000000"
                                        },
                                        display: "block",
                                        margin: "0px auto"
                                    },
                                    children: "Pay Now"
                                })
                            ]
                        })
                    ]
                });
            default:
                break;
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Dialog__WEBPACK_IMPORTED_MODULE_2___default()), {
            open: open,
            onClose: handleClose,
            "aria-labelledby": "address-modal-title",
            "aria-describedby": "address-modal-description",
            maxWidth: "md",
            fullWidth: true,
            scroll: "body",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.DialogContent, {
                sx: {
                    padding: "45px",
                    [theme.breakpoints.down("md")]: {
                        padding: "45px 15px"
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        RenderComponent(),
                        currentStep !== 0 && cartItems && priceTotal && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                            item: true,
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                sx: {
                                    backgroundColor: "whitesmoke",
                                    boxShadow: 2,
                                    borderRadius: "5px",
                                    width: "100%",
                                    justifyContent: "space-evenly",
                                    display: "flex",
                                    flexDirection: "column"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        sx: {
                                            margin: "15px",
                                            fontWeight: 500,
                                            textAlign: "center"
                                        },
                                        children: "Order Summary"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        sx: {
                                            maxHeight: 200,
                                            overflow: "auto"
                                        },
                                        children: cartItems?.map((item, index)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        container: true,
                                                        spacing: 2,
                                                        sx: {
                                                            maxWidth: "100%",
                                                            marginBottom: "10px",
                                                            marginLeft: "0px",
                                                            paddingTop: "10px"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                item: true,
                                                                xs: 12,
                                                                sm: 3,
                                                                sx: {
                                                                    [theme.breakpoints.down("sm")]: {
                                                                        justifyContent: "center",
                                                                        display: "flex"
                                                                    }
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ButtonBase__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                                    sx: {
                                                                        width: 90,
                                                                        height: 90
                                                                    },
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Img, {
                                                                        alt: "complex",
                                                                        src: `${"https://arya-ecom.s3.ap-south-1.amazonaws.com"}/product/${item?.product?._id}/${item?.product?.image?.[0]?.url}`
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                item: true,
                                                                xs: 12,
                                                                sm: 9,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                    sx: {
                                                                        textAlign: "initial"
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                            sx: {
                                                                                fontSize: "11px",
                                                                                color: "darkgoldenrod",
                                                                                textTransform: "capitalize"
                                                                            },
                                                                            children: [
                                                                                item.product.title,
                                                                                " ",
                                                                                item.product.color,
                                                                                " ",
                                                                                item.product.size
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                            sx: {
                                                                                fontSize: "11px"
                                                                            },
                                                                            children: [
                                                                                "Quantity: ",
                                                                                item.quantity
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                            sx: {
                                                                                fontSize: "11px"
                                                                            },
                                                                            children: [
                                                                                "Price: Rs. ",
                                                                                item.product.price
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }, index),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {})
                                                ]
                                            });
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        sx: {
                                            display: "flex",
                                            justifyContent: "space-between",
                                            padding: "10px 27px"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                sx: {
                                                    fontSize: "13px",
                                                    fontWeight: 500
                                                },
                                                children: "Total Price"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                sx: {
                                                    fontSize: "13px",
                                                    fontWeight: 500,
                                                    color: "darkgoldenrod"
                                                },
                                                children: [
                                                    "Rs. ",
                                                    priceTotal
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        currentStep !== 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CloseIconStyled, {
                            onClick: ()=>setCheckoutOpen(false)
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5318:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./components/Footer/FooterStyles.tsx

const Box = (0,material_.styled)("div")`
padding: 50px 60px;
background: black;
width: 100%;
@media (max-width: 1000px) {
	padding: 70px 30px;
}
`;
const Container = (0,material_.styled)("div")`
	display: flex;
	flex-direction: column;
	justify-content: center;
	max-width: 1000px;
	margin: 0 auto;
`;
const Column = (0,material_.styled)("div")`
display: flex;
flex-direction: column;
text-align: left;
margin-left: 60px;
`;
const Row = (0,material_.styled)("div")`
display: grid;
grid-template-columns: repeat(auto-fill,
						minmax(185px, 1fr));
grid-gap: 20px;

@media (max-width: 1000px) {
	grid-template-columns: repeat(auto-fill,
						minmax(200px, 1fr));
}
`;
const FooterLink = (0,material_.styled)("a")`
color: #fff;
margin-bottom: 20px;
font-size: 14px;
text-decoration: none;
letter-spacing: 3px;
display: block;
&:hover {
	color: grey;
	transition: 200ms ease-in;
}
`;
const Heading = (0,material_.styled)("p")`
font-size: 18px;
color: #fff;
font-weight: 500;
margin-bottom: 30px;
letter-spacing: 3px;
border-bottom: 1px solid;
display: inline-block;
line-height: 2.5;
@media (max-width: 900px) {
	margin-bottom: 15px;
}
`;

// EXTERNAL MODULE: ./components/Styled/index.jsx
var Styled = __webpack_require__(4426);
;// CONCATENATED MODULE: ./components/Footer/index.tsx





const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
        sx: {
            padding: "50px 60px",
            background: "#222222"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(Styled/* ContainerStyled */.N, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                container: true,
                rowSpacing: 2,
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        item: true,
                        xs: 12,
                        md: 6,
                        sx: {
                            color: "#ffffff"
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    style: {
                                        fontWeight: 600
                                    },
                                    children: "Manufactured & Marketed By:"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                " Arya Silk Mills",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                "A-UG-527 Avadh Rituraj Textile Hub, Saroli, Surat - 395003",
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    style: {
                                        fontWeight: 600
                                    },
                                    children: [
                                        "Country of Origin:",
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                    ]
                                }),
                                "India"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Heading, {
                                children: "Contact Us"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FooterLink, {
                                href: "#",
                                children: "+91 70160 22603"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FooterLink, {
                                href: "#",
                                children: "aryasilkmills@gmail.com"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                        item: true,
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Heading, {
                                children: "Social Media"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FooterLink, {
                                href: "#",
                                children: "Facebook"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FooterLink, {
                                href: "#",
                                children: "Instagram"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FooterLink, {
                                href: "#",
                                children: "Twitter"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(FooterLink, {
                                href: "#",
                                children: "Youtube"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_Footer = (Footer);


/***/ }),

/***/ 1920:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* unused harmony export MenuIconStyled */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1939);
/* harmony import */ var _mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6910);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_AddShoppingCart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1747);
/* harmony import */ var _mui_icons_material_AddShoppingCart__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddShoppingCart__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(439);
/* harmony import */ var _styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9332);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _sideNavbar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7924);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _cart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6487);
/* harmony import */ var _services_api_services__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6202);
/* harmony import */ var _Checkout__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6235);
/* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1660);
/* harmony import */ var _Styled__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4426);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_sideNavbar__WEBPACK_IMPORTED_MODULE_8__, _cart__WEBPACK_IMPORTED_MODULE_10__, _services_api_services__WEBPACK_IMPORTED_MODULE_11__, _Checkout__WEBPACK_IMPORTED_MODULE_12__, _Search__WEBPACK_IMPORTED_MODULE_13__]);
([_sideNavbar__WEBPACK_IMPORTED_MODULE_8__, _cart__WEBPACK_IMPORTED_MODULE_10__, _services_api_services__WEBPACK_IMPORTED_MODULE_11__, _Checkout__WEBPACK_IMPORTED_MODULE_12__, _Search__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const MenuIconStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.styled)((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_1___default()))({
    // position: "fixed",
    // top: 20,
    // left: 50,
    cursor: "pointer",
    fontSize: 30,
    zIndex: 1000,
    strokeWidth: 1
});
function Header({ children  }) {
    const { push  } = (0,next_navigation__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useTheme)();
    const desktop = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)(theme.breakpoints.up("md"));
    const tablet = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)(theme.breakpoints.between("sm", "md"));
    const mobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)(theme.breakpoints.down("sm"));
    // async function fetchData() {
    //   const call = await get('/category/all')
    // }
    //   useEffect(() => {
    //   fetchData()
    //   }, [])
    const [menuShow, setMenuShow] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [cartShow, setCartShow] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [checkoutOpen, setCheckoutOpen] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const [searchOpen, setSearchOpen] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().mainHeader),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sideNavbar__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                        menuShow: menuShow,
                        setMenuStatus: (data)=>setMenuShow(data)
                    }),
                    !searchOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Styled__WEBPACK_IMPORTED_MODULE_14__/* .ContainerStyled */ .N, {
                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().mainHeaderContainer),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                style: {
                                    display: "flex",
                                    gap: "20px",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    width: "100%"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            width: "50%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MenuIconStyled, {
                                            onClick: ()=>setMenuShow(!menuShow)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            justifyContent: "center",
                                            display: "flex",
                                            cursor: "pointer",
                                            marginLeft: "4%",
                                            touchAction: "none",
                                            width: "50%",
                                            flex: 1
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_15___default()), {
                                            href: "/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/logo-transperant.png",
                                                style: {
                                                    width: "125px",
                                                    cursor: "pointer"
                                                },
                                                alt: ""
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().iconList),
                                children: [
                                    desktop && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Search__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().iconDev),
                                        onClick: ()=>push("/account/profile"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Person__WEBPACK_IMPORTED_MODULE_2___default()), {})
                                    }),
                                    !desktop && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().iconDev),
                                        onClick: ()=>setSearchOpen(!searchOpen),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_3___default()), {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().iconDev),
                                        onClick: ()=>push("/account/wishlist"),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_4___default()), {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().iconDev),
                                        onClick: ()=>setCartShow(!cartShow),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddShoppingCart__WEBPACK_IMPORTED_MODULE_5___default()), {})
                                    })
                                ]
                            })
                        ]
                    }),
                    !desktop && searchOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Styled__WEBPACK_IMPORTED_MODULE_14__/* .ContainerStyled */ .N, {
                        className: (_styles_Layout_module_scss__WEBPACK_IMPORTED_MODULE_16___default().mainHeaderContainer),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            style: {
                                display: "flex",
                                gap: "20px",
                                alignItems: "center",
                                justifyContent: "space-between",
                                width: "100%"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Search__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sideNavbar__WEBPACK_IMPORTED_MODULE_8__/* .CloseIconStyled */ .Mg, {
                                        onClick: ()=>setSearchOpen(!searchOpen)
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        cartShow: cartShow,
                        setCartStatus: (data)=>setCartShow(data),
                        setCheckoutOpen: (data)=>setCheckoutOpen(data)
                    }),
                    checkoutOpen && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Checkout__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        setCheckoutOpen: (data)=>setCheckoutOpen(data)
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                children: children
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5837:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Layout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1920);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5318);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Header__WEBPACK_IMPORTED_MODULE_1__]);
_Header__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Layout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                style: {
                    minHeight: "100vh"
                },
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1660:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Search)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2311);
/* harmony import */ var _mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _services_products_services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(546);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4305);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _sideNavbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7924);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7915);
/* harmony import */ var _mui_icons_material__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_products_services__WEBPACK_IMPORTED_MODULE_6__, _sideNavbar__WEBPACK_IMPORTED_MODULE_9__]);
([_services_products_services__WEBPACK_IMPORTED_MODULE_6__, _sideNavbar__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












function sleep(delay = 0) {
    return new Promise((resolve)=>{
        setTimeout(resolve, delay);
    });
}
function Search() {
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(false);
    const [options, setOptions] = react__WEBPACK_IMPORTED_MODULE_1__.useState([]);
    const [searchText, setSearchText] = react__WEBPACK_IMPORTED_MODULE_1__.useState("");
    const loading = open && options.length === 0;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        let active = true;
        if (!loading) {
            return undefined;
        }
        // (async () => {
        //   await sleep(1e3); // For demo purposes.
        //   if (active) {
        //     setOptions([...topFilms]);
        //   }
        // })();
        return ()=>{
            active = false;
        };
    }, [
        loading
    ]);
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (!open) {
            setOptions([]);
            setSearchText("");
        }
    }, [
        open
    ]);
    react__WEBPACK_IMPORTED_MODULE_1__.useEffect(()=>{
        if (searchText && !options.length) {
            setOpen(false);
        }
    }, [
        searchText
    ]);
    const searchCall = async (query)=>{
        if (!query) return;
        try {
            const response = await (0,_services_products_services__WEBPACK_IMPORTED_MODULE_6__/* .searchProductsService */ .tA)({
                text: query
            });
            const data = response?.data?.data;
            // setOptions([...response?.data?.data]);
            return data;
        } catch (error) {
            console.log(error);
            return;
        }
    };
    const debouncedFetchData = lodash_debounce__WEBPACK_IMPORTED_MODULE_7___default()(async (query)=>{
        setSearchText(query);
        const res = await searchCall(query);
        console.log("res", res);
        setOptions(res || []);
    }, 500);
    const StyledOption = (0,_mui_material__WEBPACK_IMPORTED_MODULE_11__.styled)("li")(({ theme  })=>({
            padding: theme.spacing(1),
            display: "flex",
            alignItems: "center",
            borderBottom: "1px solid #ccc",
            "& > svg": {
                marginRight: theme.spacing(1)
            }
        }));
    function renderOption(props, option, { selected  }) {
        console.log(props);
        const label = props.key;
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyledOption, {
            selected: selected,
            component: "li",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_11__.ListItemText, {
                primary: label
            })
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_3___default()), {
            id: "search-bar",
            size: "small",
            sx: {
                width: 300
            },
            open: open,
            onOpen: ()=>{
                setOpen(searchText ? true : false);
            },
            onClose: ()=>{
                setOpen(false);
            },
            isOptionEqualToValue: (option, value)=>option.title === value.title,
            getOptionLabel: (option)=>option.title,
            options: options,
            loading: loading,
            onChange: (event, option)=>{
                if (option) {
                    router.push({
                        pathname: `/products/${option?.slug}`
                    });
                    setOptions([]);
                    setSearchText("");
                    setOpen(false);
                    event.target.value = "";
                }
            },
            popupIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
            // clearIcon={<CloseIconStyled sx={{width: "80%", }}/>}
            renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_2___default()), {
                    sx: {
                        border: "#000",
                        color: "$000",
                        outline: "#000"
                    },
                    variant: "standard",
                    placeholder: "Search",
                    ...params,
                    onChange: (e)=>debouncedFetchData(e.target.value),
                    InputProps: {
                        ...params.InputProps,
                        startAdornment: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_11__.InputAdornment, {
                            position: "start",
                            children: [
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_5___default()), {})
                            ]
                        }),
                        endAdornment: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                            children: [
                                loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    color: "inherit",
                                    size: 20
                                }) : null,
                                params.InputProps.endAdornment
                            ]
                        })
                    }
                }),
            renderOption: (props, option, state)=>renderOption(props, option, state)
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3716);
/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5837);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_promise_tracker__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(312);
/* harmony import */ var react_promise_tracker__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_promise_tracker__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_7__]);
([_components_Layout__WEBPACK_IMPORTED_MODULE_3__, react_toastify__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Spinner = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        style: {
            display: "flex",
            position: "fixed",
            opacity: "100%",
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
            justifyContent: "center",
            alignItems: "center",
            zIndex: 9999
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_6__.Circles, {
            height: "70",
            width: "70",
            color: "darkgoldenrod",
            ariaLabel: "circles-loading",
            wrapperStyle: {},
            wrapperClass: "",
            visible: true
        })
    });
};
function App({ Component , pageProps  }) {
    const { promiseInProgress  } = (0,react_promise_tracker__WEBPACK_IMPORTED_MODULE_5__.usePromiseTracker)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.createTheme)({
        palette: {
            primary: {
                main: "#0052cc"
            },
            secondary: {
                main: "#daa520"
            }
        },
        typography: {
            "fontFamily": `"Poppins", sans-serif`,
            "fontSize": 14,
            "fontWeightLight": 300,
            "fontWeightRegular": 400,
            "fontWeightMedium": 500
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ThemeProvider, {
        theme: theme,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_4__.Suspense, {
            fallback: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Spinner, {}),
            children: [
                promiseInProgress && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Spinner, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_7__.ToastContainer, {
                            position: "top-right",
                            toastOptions: {
                                duration: 7000
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                            ...pageProps
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1232:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A1": () => (/* binding */ createOrderService),
/* harmony export */   "J1": () => (/* binding */ paymentSuccessService),
/* harmony export */   "qg": () => (/* binding */ paymentFailureService)
/* harmony export */ });
/* harmony import */ var _api_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6202);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_services__WEBPACK_IMPORTED_MODULE_0__]);
_api_services__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const createOrderService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/payment/orders", body);
};
const paymentSuccessService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/payment/success", body);
};
const paymentFailureService = (body)=>{
    return (0,_api_services__WEBPACK_IMPORTED_MODULE_0__/* .post */ .v_)("/payment/failure", body);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 3716:
/***/ (() => {



/***/ }),

/***/ 7915:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material");

/***/ }),

/***/ 6146:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 1747:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/AddShoppingCart");

/***/ }),

/***/ 4173:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 2908:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/CreditScoreOutlined");

/***/ }),

/***/ 4124:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/EmojiEventsOutlined");

/***/ }),

/***/ 6910:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 5967:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/FavoriteBorderOutlined");

/***/ }),

/***/ 6380:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/HighlightOff");

/***/ }),

/***/ 3804:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LocationOnOutlined");

/***/ }),

/***/ 3254:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/LockResetOutlined");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 206:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PermIdentity");

/***/ }),

/***/ 1939:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Person");

/***/ }),

/***/ 7470:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/PowerSettingsNewOutlined");

/***/ }),

/***/ 9509:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Remove");

/***/ }),

/***/ 8017:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 2311:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Autocomplete");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 2494:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ButtonBase");

/***/ }),

/***/ 9048:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 8611:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Dialog");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 5612:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 4192:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/List");

/***/ }),

/***/ 834:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItem");

/***/ }),

/***/ 1011:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemButton");

/***/ }),

/***/ 3787:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 1598:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 4180:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/SwipeableDrawer");

/***/ }),

/***/ 6042:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 6781:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ToggleButton");

/***/ }),

/***/ 5951:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ToggleButtonGroup");

/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 4989:
/***/ ((module) => {

"use strict";
module.exports = require("country-state-city");

/***/ }),

/***/ 4305:
/***/ ((module) => {

"use strict";
module.exports = require("lodash.debounce");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 1223:
/***/ ((module) => {

"use strict";
module.exports = require("react-loader-spinner");

/***/ }),

/***/ 312:
/***/ ((module) => {

"use strict";
module.exports = require("react-promise-tracker");

/***/ }),

/***/ 1929:
/***/ ((module) => {

"use strict";
module.exports = require("react-select");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [332,664,130,77,462,354,992], () => (__webpack_exec__(6004)));
module.exports = __webpack_exports__;

})();