"use strict";
(() => {
var exports = {};
exports.id = 748;
exports.ids = [748];
exports.modules = {

/***/ 6507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/google"
const google_namespaceObject = require("next-auth/providers/google");
var google_default = /*#__PURE__*/__webpack_require__.n(google_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js


// import EmailProvider from "next-auth/providers/email"
// import AppleProvider from "next-auth/providers/apple"
// For more information on each option (and a full list of options) go to
// https://next-auth.js.org/configuration/options
/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    // https://next-auth.js.org/configuration/providers
    providers: [
        google_default()({
            clientId: `${"695977102477-tt3qn74pjctsp71ahvppegk18jsm60q8.apps.googleusercontent.com"}`,
            clientSecret: `${"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"}`
        })
    ],
    secret: "@!Ecom_dev@NexT@%$!+*&Dk",
    session: {
        // Use JSON Web Tokens for session instead of database sessions.
        // This option can be used with or without a database for users/accounts.
        // Note: `strategy` should be set to 'jwt' if no database is used.
        strategy: "jwt"
    },
    jwt: {
        secret: "@!Ecom_dev@NexT@%$!+*&Dk"
    },
    callbacks: {
        async jwt ({ token , account , user , profile  }) {
            token.id_token = account?.id_token;
            token.googleId = account?.providerAccountId;
            return token;
        },
        async session ({ session , token , user  }) {
            return session;
        }
    }
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6507));
module.exports = __webpack_exports__;

})();